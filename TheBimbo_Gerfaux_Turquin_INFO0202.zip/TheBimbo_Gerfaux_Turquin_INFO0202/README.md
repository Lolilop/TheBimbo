# **The Bimbo**
**Auteurs :** Théo Gerfaux, Johan Turquin (groupe S2A3B)
## Description du jeu
* Le but du jeu est d'atteindre l'objectif représenté par un hélicoptère à droite de l'écran, en évitant les deux ennemis qui vous tuent quand vous vous approchez de trop près
* Vous pouvez vous déplacer avec les flèches du clavier en maintenant la touche alt, ou en cliquant sur les boutons
## Configuration pour lancer le jeu
Version Java : **Java 11**<br>
EDI : **NetBeans 10**<br>
*Développé avec Java Swing, intégré dans un lanceur JavaFX*
## Instructions
* Simplement lancer le projet NetBeans et cliquer sur le bouton "Change Game" dans la fenêtre qui s'ouvre
* Lors du premier lancement du jeu, survoler le centre de la fenêtre avec la souris pour charger les boutons et cliquer sur un des quatres boutons pour charger l'image du jeu
<br><br>
**Javadoc disponible dans le dossier javadoc, à la racine du projet**
