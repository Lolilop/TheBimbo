package thebimbo.decisionmakers;



/**
 * Joueur du jeu TheBimbo
 * @author Theo gerfaux 
 * @author Johan Turquin
 * @see DecisionMaker
 */

public class Player extends DecisionMaker {

    
    /*##########################################################################
    #                                BUILDER                                   #
    ##########################################################################*/ 

    /**
     * Constructeur par initialisation de la classe Player
     * @param x la position sur l'axe des abscisses
     * @param y la position sur l'axe des ordonn&eacute;es
     */

    public Player(int x, int y) {
        super(x,y,VITESSE_JOUEUR);
    }
    
    /*##########################################################################
    #                             END BUILDER                                  #
    ##########################################################################*/
    
    
    
    
    /*##########################################################################
    #                                 METHODE                                  #
    ##########################################################################*/
    
    /**
     * Permet de d&eacute;placer le joueur dans la direction donn&eacute;e
     * @param direction la direction du joueur
     */
    @Override
    public void move(String direction) {
        if(direction.equals("Haut")){
            directionNorth();
        }else if(direction.equals("Bas")){
            directionSouth();
        }else if(direction.equals("Droite")){
            directionEast();
        }else if(direction.equals("Gauche")){
            directionWest();
        }
        
    }
    
        

    
    
    /*##########################################################################
    #                             END METHODE                                  #
    ##########################################################################*/
}
