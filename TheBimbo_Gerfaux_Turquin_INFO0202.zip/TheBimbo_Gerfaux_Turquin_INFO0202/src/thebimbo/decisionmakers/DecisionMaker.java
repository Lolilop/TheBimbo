package thebimbo.decisionmakers;

import java.io.IOException;



/**
 * Classe m&egrave;re de toutes les entit&eacute;s du jeu (joueur et ennemis)
 * @author Theo gerfaux et Johan Turquin
 * version 3.0
 */

public abstract class DecisionMaker implements IDecisionMaker, java.io.Serializable{

    /*##########################################################################
    #                                ATTRIBUS                                  #
    ##########################################################################*/
    /**
     * La vitesse du joueur
     */
    public static int VITESSE_JOUEUR=10;
    
    /**
     * La vitesse des ennemis
     */
    public static int VITESSE_ENNEMI=5;
    
    /**
     * La position sur l'axe des abscisses
     */
    private int posX;
    
    /**
     * La position sur l'axe des ordonn&eacute;es
     */
    private int posY;
    
    /**
     * La vitesse de l'entit&eacute;
     */
    private int vitesse;
    
    /**
     * La position pr&eacute;c&eacute;dente sur l'axe des abscisses
     */
    private int previousPosX;
    
    /**
     * La position pr&eacute;c&eacute;dente sur l'axe des ordonn&eacute;es
     */
    private int previousPosY;
    
    public final byte ZERO = 0;
    public final byte UN = 1;
    
    
    /*##########################################################################
    #                            END ATTRIBUS                                  #
    ##########################################################################*/
    
    /*##########################################################################
    #                                BUILDER                                   #
    ##########################################################################*/

    /**
     * Constructeur par initialisation de l'entit&eacute;
     * @param x la position sur l'axe des abscisses
     * @param y la position sur l'axe des ordonn&eacute;es
     * @param v la vitesse
     */

    public DecisionMaker(int x, int y, int v) {
        this.posX = x;
        this.posY = y;
        previousPosX=x;
        previousPosY=y;
        vitesse=v;
    }
   
    
    /*##########################################################################
    #                             END BUILDER                                  #
    ##########################################################################*/
    
    /*##########################################################################
    #                             ASCENSEURS                                   #
    ##########################################################################*/

    /**
     * @return la position sur l'axe des abscisses
     */
    @Override
    public int getX(){
        return this.posX;
    }

    /**
     * @return la position sur l'axe des ordonn&eacute;es
     */

    @Override
    public int getY(){
        return this.posY;
    }
    
    /**
     * @return la position pr&eacute;c&eacute;dente sur l'axe des abscisses
     */

    public int getPreviousPosX(){
        return previousPosX;
    }
    
    /**
     * @return la position pr&eacute;c&eacute;dente sur l'axe des ordonn&eacute;es
     */
    public int getPreviousPosY(){
        return previousPosY;
    }
    
    /**
     * Permet de modifier la position pr&eacute;c&eacute;dente sur l'axe des ordonn&eacute;es
     * @param nb la position pr&eacute;c&eacute;dente sur l'axe des ordonn&eacute;es
     */
    public void setPreviousPosY(int nb){
        previousPosY=nb;
    }
    
    /**
     * Permet de modifier la position pr&eacute;c&eacute;dente sur l'axe des abscisses
     * @param nb la position pr&eacute;c&eacute;dente sur l'axe des abscisses
     */
     public void setPreviousPosX(int nb){
        previousPosX=nb;
    }
    
    
    
   /**
     * Permet de modifier la position actuelle sur l'axe des abscisses
     * @param x la position actuelle sur l'axe des abscisses
     */
    @Override
    public void setX(int x) {
        posX = x;
    }
    
    /**
     * Permet de modifier la position actuelle sur l'axe des ordonn&eacute;es
     * @param y la position actuelle sur l'axe des ordonn&eacute;es
     */

    @Override
    public void setY(int y) {
        posY = y;
    }
    
    /*##########################################################################
    #                             END ASCENSEURS                               #
    ##########################################################################*/
    
    /*##########################################################################
    #                                 METHODE                                  #
    ##########################################################################*/

    /**
     * Permet d'incr&eacute;menter la position sur l'axe des abscisses
     * @param x le nombre &agrave; ajouter
     */

    public void addX(int x){
        this.posX += x;
    }

    /**
     * Permet d'incr&eacute;menter la position sur l'axe des ordonn&eacute;es
     * @param y le nombre &agrave; ajouter
     */

    public void addY(int y){
        this.posY += y;
    }

       
    /*##########################################################################
    #                             END METHODE                                  #
    ##########################################################################*/
    
    /*##########################################################################
    #                             METHODE ABSTRACT                             #
    ##########################################################################*/

    /**
     * Permet de d&eacute;placer l'entit&eacute; vers le haut de l'&eacute;cran
     */

    public void directionNorth() {
        addY(-vitesse);
    }

    /**
     * Permet de d&eacute;placer l'entit&eacute; vers le bas de l'&eacute;cran
     */

    public void directionSouth() {
        addY(vitesse);
    }

    /**
     * Permet de d&eacute;placer l'entit&eacute; vers la droite de l'&eacute;cran
     */

    public void directionEast() {
        addX(vitesse);
    }

    /**
     * Permet de d&eacute;placer l'entit&eacute; vers la gauche de l'&eacute;cran
     */

    public void directionWest() {
        addX(-vitesse);

    }

    /**
     * Permet de d&eacute;placer l'entit&eacute; dans la direction donn&eacute;e
     * @param direction la direction
     */
    public abstract void move(String direction);
    
    /*##########################################################################
    #                         END METHODE ABSTRACT                             #
    ##########################################################################*/    
}
