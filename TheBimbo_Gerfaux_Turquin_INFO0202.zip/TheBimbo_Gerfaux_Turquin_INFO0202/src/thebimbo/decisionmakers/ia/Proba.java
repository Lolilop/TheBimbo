package thebimbo.decisionmakers.ia;

import thebimbo.decisionmakers.DecisionMaker;
import thebimbo.decisionmakers.Player;


/**
 * Ennemi se d&eacute;placant al&eacute;atoirement &agrave; grande distance du joueur<br>
 * Prend le joueur en chasse quand celui-ci est proche
 * @author Theo gerfaux *
 * @author Johan Turquin
 * @see DecisionMaker
 */

public class Proba extends DecisionMaker{

    /*##########################################################################
    #                                ATTRIBUTS                                  #
    ##########################################################################*/
    
    /**
     * Joueur de la partie en cours
     */
    private Player player;

    /*##########################################################################
    #                            END ATTRIBUS                                  #
    ##########################################################################*/

    /*##########################################################################
    #                                BUILDER                                   #
    ##########################################################################*/

    /**
     * Constructeur par initialisation de l'ennemi
     * @param x la position sur l'axe des abscisses
     * @param y la position sur l'axe des ordonn&eacute;es
     * @param p le joueur de la partie en cours
     */
    public Proba(int x, int y, Player p) {
        super(x,y,VITESSE_ENNEMI);
        player=p;
    }
    

    /*##########################################################################
    #                             END BUILDER                                  #
    ##########################################################################*/

    /*##########################################################################
    #                                 METHODE                                  #
    ##########################################################################*/
    
    /**
     * Permet de d&eacute;placer l'ennemi
     * @param direction la direction (non utilis&eacute;, n&eacute;cessaire pour l'h&acute;ritage)
     */

    @Override
    public void move(String direction) {
        double distanceX = getX()-player.getX();
        
        double distanceY = getY()-player.getY();
        System.out.println(distanceX+" | "+distanceY);
        double distance=Math.sqrt(distanceX*distanceX+distanceY*distanceY);
        
        if(distance<=200 & Math.random()<0.85){
            if(Math.abs(distanceX)>=Math.abs(distanceY)){
                rapprochementX();
            }else{
                rapprochementY();
            }
        }else{
            deplacementAleatoire();
        }
        
        
        
        
        
    }
    
  
    private void deplacementAleatoire(){
        int axe = (int)(Math.random()*2);
        
        double direc=(Math.random()*2)-1;
        
        int dir=0;
        
        if(direc<0){
            dir=-1;
        }else{
            dir=1;
        }
        
        if(axe==0){
            if(dir==1){
                directionEast();
            }else{
                directionWest();
            }
        }else{
            if(dir==1){
                directionSouth();
            }else{
                directionNorth();
            }
        }
    }
    
   
    private void rapprochementX(){
        if(getX()>=player.getX()){
            this.addX(-VITESSE_ENNEMI);
        }else{
            this.addX(VITESSE_ENNEMI);
        }
    }
    
    private void rapprochementY(){
        if(getY()>=player.getY()){
            this.addY(-VITESSE_ENNEMI);
        }else{
            this.addY(VITESSE_ENNEMI);
        }
    }
    
    /*##########################################################################
    #                             END METHODE                                  #
    ##########################################################################*/
 }
