package thebimbo.decisionmakers;

/**
 * Interface des entit&eacute;s du jeu
 * @author Johan Turquin
 * @author Th&eacute;o Gerfaux
 */
public interface IDecisionMaker {
    
    /**
     * Permet d'obtenir la position sur l'axe des abscisses
     * @return la position sur l'axe des abscisses
     */
    public int getX();
    
    /**
     * Permet d'obtenir la position sur l'axe des ordonn&eacute;es
     * @return la position sur l'axe des ordonn&eacute;es
     */
    public int getY();
    
    /**
     * Permet de modifier la position sur l'axe des abscisses
     * @param x la nouvelle position sur l'axe des abscisses
     */
    public void setX(final int x);
    
    /**
     * Permet de modifier la position sur l'axe des ordonn&eacute;es
     * @param y la nouvelle position sur l'axe des ordonn&eacute;es
     */
    public void setY(final int y);

    
}
