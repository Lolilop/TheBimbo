package thebimbo.mainPackage;



import thebimbo.interfaces.GameLauncher;





/**
 *
 * @author Johan Turquin et Th&eacute;o Gerfaux
 */

public class main {

    public static void main(String[] args){

        GameLauncher g = new GameLauncher();

    }



}
