/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thebimbo.manager;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import thebimbo.decisionmakers.DecisionMaker;
import thebimbo.decisionmakers.Player;
import thebimbo.decisionmakers.ia.Proba;
import thebimbo.interfaces.GamePanel;


/**
 * Manager du jeu TheBimbo
 * @author Théo Gerfaux
 * @author Johan Turquin
 */
public class Manager{
    
    /*##########################################################################
    #                                ATTRIBUS                                  #
    ##########################################################################*/
    
    /**
     * Joueur interpr&eacute;tant Bimbo
     * @see DecisionMaker
     */
    private DecisionMaker joueur1;
    
    /**
     * Premier ennemi
     * @see DecisionMaker
     */
    private DecisionMaker joueur2;
    
    /**
     * Deuxi&egrave;me ennemi
     * @see DecisionMaker
     */
    private DecisionMaker joueur3;
    
    /**
     * La position de l'objectif sur l'axe des abscisses, un entier
     */
    private int objectifX;
    
    /**
     * La position de l'objectif sur l'axe des ordonn&eacute;es, un entier
     */
    private int objectifY;
    
    
    /**
     * Constructeur par initialisation du Manager
     * @param j1 Joueur 1, interpr&eacute;tant Bimbo
     * @param j2 Ennemi 1
     * @param j3 Ennemi 2
     * @see DecisionMaker
     */
    
    public Manager(DecisionMaker j1, DecisionMaker j2, DecisionMaker j3){
        
        this.joueur1 = j1;
        this.joueur2 = j2;
        joueur3=j3;
    }

    /**
     * Constructeur par copie du Manager
     * @param m le Manager &agrave; copier
     */
    public Manager(Manager m){
        joueur1=m.joueur1;
        joueur2=m.joueur2;
        joueur3=m.joueur3;
    }
    
    /*##########################################################################
    #                             END BUILDER                                  #
    ##########################################################################*/
    
    /*##########################################################################
    #                             ASCENSEURS                                   #
    ##########################################################################*/
    
    
    /**
     * Permet d'obtenir le joueur
     * @return le joueur
     */
    
    public Player getPlayer1(){
        return (Player)joueur1;
    }
    
    /**
     * Permet d'obtenir l'ennemi 1
     * @return l'ennemi 1
     */
    public Proba getPlayer2(){
        return (Proba)joueur2;
    }
    
    /**
     * Permet d'obtenir l'ennemi 2
     * @return l'ennemi 2
     */
    public Proba getPlayer3(){
        return (Proba)joueur3;
    }
    
    /**
     * Permet de changer la coordonn&eacute;e sur l'axe des abscisses de l'objectif
     * @param nb la nouvelle valeur
     */
    public void setObjectifX(int nb){
        objectifX=nb;
    }
    
    /**
     * Permet de changer la coordonn&eacute;e sur l'axe des ordonn&eacute;es de l'objectif
     * @param nb la nouvelle valeur
     */
    public void setObjectifY(int nb){
        objectifY=nb;
    }
    
    /**
     * Permet d'obtenir la coordonn&eacute;e sur l'axe des abscisses de l'objectif
     * @return la coordonn&eacute;e sur l'axe des abscisses de l'objectif, un entier
     */
    public int getObjectifX(){
        return objectifX;
    }
    
    /**
     * Permet d'obtenir la coordonn&eacute;e sur l'axe des ordonn&eacute;es de l'objectif
     * @return la coordonn&eacute;e sur l'axe des ordonn&eacute;es de l'objectif, un entier
     */
    public int getObjectifY(){
        return objectifY;
    }
    
    
    /**
     * Permet de d&eacute;placer le joueur
     * @param direction la direction dans laquelle le joueur se d&eacute;place
     */
    
    public void movePlayer1(String direction){
        joueur1.move(direction);
    }
       
    /**
     * Permet de d&eacute;placer l'ennemi 1
     */
    
    public void movePlayer2(){
        joueur2.move("");
    }
    
    /**
     * Permet de d&eacute;placer l'ennemi 2
     */
    
    public void movePlayer3(){
        joueur3.move("");
    }
    
    /**
     * Permet de r&eacute;initialiser les donn&eacute;es du jeu
     * @param gp le panel contenant le jeu (permet de r&eacute;cr&eacute;er les joueurs et les ennemis avec leurs coordonn&eacute;es par d&eacute;faut)
     */

    public void reset(GamePanel gp){
        
        joueur1 = gp.newPlayer();
        joueur2 = gp.newEnemy((Player)joueur1,20);
        joueur3 = gp.newEnemy((Player)joueur1,-20);
    }
    
    /**
     * Permet de charger une partie
     * @param file le fichier &agrave; charger
     */
    public void load(File file){
        try{
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file));
            joueur1=(DecisionMaker)ois.readObject();
            joueur2=(DecisionMaker)ois.readObject();
            joueur3=(DecisionMaker)ois.readObject();
            ois.close();
        }catch(ClassNotFoundException e){
            System.out.println(e+" : classe introuvable ");
        }catch(IOException e){
            e.printStackTrace();
            System.err.println("Chargement de la partie impossible");
        }
    }
    
    /**
     * Permet de sauvegarder la partie
     * @param file le fichier contenant la sauvegarde
     */
    public void save(File file){
        try{
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file));
            oos.writeObject(joueur1);
            oos.writeObject(joueur2);
            oos.writeObject(joueur3);
            oos.close();
        }catch(IOException e){
            e.printStackTrace();
            System.err.println("Impossible de sauvegarder la partie");
        }
    }
    
    /*##########################################################################
    #                             END METHODE                                  #
    ##########################################################################*/
}
