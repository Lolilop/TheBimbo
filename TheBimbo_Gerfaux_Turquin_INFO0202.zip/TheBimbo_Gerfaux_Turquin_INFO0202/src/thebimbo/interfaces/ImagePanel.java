/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thebimbo.interfaces;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 * Permet de cr&eacute;er un JPanel contenant une image
 * @author Théo Gerfaux
 */
public class ImagePanel extends javax.swing.JPanel{
    /**
     * Le JLabel contenant l'image
     */
    JLabel label;
    
    /**
     * Constructeur par initialisation de la classe ImagePanel
     * @param i l'image &agrave; ajouter au JPanel
     */
    public ImagePanel(ImageIcon i){
        super();
        label=new JLabel(i);
        this.add(label);
        
    }
    
}
