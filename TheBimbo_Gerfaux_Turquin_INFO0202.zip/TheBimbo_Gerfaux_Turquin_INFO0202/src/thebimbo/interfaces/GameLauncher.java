package thebimbo.interfaces;

import java.awt.BorderLayout;
import launcher.Game.Game;
import javax.swing.JFrame;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;


import thebimbo.manager.Manager;
import thebimbo.decisionmakers.Player;
import thebimbo.decisionmakers.ia.Proba;


/**
 * Permet de lancer le jeu
 * @author Theo gerfaux
 * @author Johan Turquin
 */

public class GameLauncher extends Game{

    /*##########################################################################
    #                                ATTRIBUS                                  #
    ##########################################################################*/
    
    /**
     * Barre de menu de la fen&egrave;tre de lancement
     */
    private JMenuBar barre;
    
    /**
     * Onglet fichier de la barre de menu
     */
    private JMenu fichier;
    
    /**
     * Item servant &agrave; quitter le jeu
     */
    private JMenuItem quitter;
    
    /**
     * Item servant &agrave; stopper le jeu
     */
    private JMenuItem stop;
    
    /**
     * Item servant &agrave; mettre le jeu en pause
     */
    private JMenuItem pause;
    
    /**
     * Item servant &agrave; continuer une partie en pause ou en d&eacute;marrer une nouvelle
     */
    private JMenuItem play;
    
    /**
     * JPanel des graphismes du jeu
     * @see GamePanel
     */
    private GamePanel gamePanel;

    /**
     * Manager des donn&eacute;es du jeu
     * @see Manager
     */
    private Manager manager;

    /**
     * JPanel contenant la totalit&eacute; des &eacute;l&eacute;ments graphiques du jeu
     */
    private JPanel contentPane;
    
    /**
     * Joueur de la partie en cours
     * @see Player
     */
    private Player player;
    
    /**
     * Ennemi 1 de la partie en cours
     * @see Proba
     */
    private Proba player2;
    
    /**
     * Ennemi 2 de la partie en cours
     * @see Proba
     */
    private Proba player3;
    
    /**
     * Bool&eacute;en indiquant si le jeu est en pause
     */
    private boolean gamePaused=false;
    

    /*##########################################################################
    #                            END ATTRIBUS                                  #
    ##########################################################################*/

    /*##########################################################################
    #                                BUILDER                                   #
    ##########################################################################*/

    /**
     * Constructeur par d&eacute;faut du jeu<br>
     * Permet de cr&eacute;er une fen&ecirc;tre pour lancer le jeu
     */

    public GameLauncher() { //nouvelle fenêtre
        super("TheBimbo");
        contentPane=new JPanel();
        player = new Player(0,0);
        player2 = new Proba(0,0,player);
        player3 = new Proba(0,0,player);
        manager=new Manager(player ,player2,player3);
        
        initComponents();
        gamePanel=new GamePanel(contentPane,manager);
        contentPane.removeAll();

        add(gamePanel);

        initComponents();
        
    
        contentPane.repaint();
        contentPane.revalidate();
        

        
        JFrame f = new JFrame("TheBimbo");
        


        Toolkit t = Toolkit.getDefaultToolkit();
        Dimension resolution = t.getScreenSize();

        f.setSize(contentPane.getPreferredSize());

        genererMenu(f);
        f.getContentPane().add(contentPane);
        f.setLocationRelativeTo(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);


    }

   

    /**
     * Constructeur par parent du jeu<br>
     * Permet d'inclure le jeu dans un JPanel
     * @param parent le JPanel parent
     */

    public GameLauncher(javax.swing.JPanel parent){ //inclusion dans un JPanel 
        super("TheBimbo");
        contentPane=new JPanel();
        player = new Player(0,0);
        player2 = new Proba(0,0,player);
        player3 = new Proba(0,0,player);
        manager=new Manager(player ,player2,player3);
        
        initComponents();
        gamePanel=new GamePanel(contentPane,manager);
        contentPane.removeAll();

        add(gamePanel);

        initComponents();
        
    
        parent.add(contentPane);
        contentPane.repaint();
        contentPane.revalidate();

    }


    /*##########################################################################
    #                             END BUILDER                                  #
    ##########################################################################*/

    /*##########################################################################
    #                                 METHODE                                  #
    ##########################################################################*/

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setLayout(new java.awt.GridLayout(2, 1));

        jPanel2.setLayout(new java.awt.GridLayout(2, 3));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 425, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 112, Short.MAX_VALUE)
        );

        jPanel2.add(jPanel4);

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/thebimbo/images/fleche-haut.png"))); // NOI18N
        jButton4.setMnemonic('z');
        jButton4.setToolTipText("");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jButton4.setMnemonic(KeyEvent.VK_UP);
        jPanel2.add(jButton4);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 425, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 112, Short.MAX_VALUE)
        );

        jPanel2.add(jPanel5);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/thebimbo/images/fleche-gauche.png"))); // NOI18N
        jButton1.setMnemonic('q');
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jButton1.setMnemonic(KeyEvent.VK_LEFT);
        jPanel2.add(jButton1);

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/thebimbo/images/fleche-bas.png"))); // NOI18N
        jButton2.setMnemonic('s');
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jButton2.setMnemonic(KeyEvent.VK_DOWN);
        jPanel2.add(jButton2);

        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/thebimbo/images/fleche-droite.png"))); // NOI18N
        jButton5.setMnemonic('d');
        jButton5.setToolTipText("");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jButton5.setMnemonic(KeyEvent.VK_RIGHT);
        jPanel2.add(jButton5);

        add(jPanel2);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        //gauche();
        gamePanel.movePlayer1("Gauche");
        gamePanel.movePlayer2(); 
        gamePanel.movePlayer3();
        contentPane.repaint();
        
        if(gamePanel.gameLost()) defaite();
        else if(gamePanel.gameWon()) victoire();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        //haut();
        gamePanel.movePlayer1("Haut");
        gamePanel.movePlayer2();   
        gamePanel.movePlayer3();
        contentPane.repaint();
        
        if(gamePanel.gameLost()) defaite();
        else if(gamePanel.gameWon()) victoire();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        //bas();
        gamePanel.movePlayer1("Bas");
        gamePanel.movePlayer2();  
        gamePanel.movePlayer3();
        contentPane.repaint();
        if(gamePanel.gameLost()) defaite();
        else if(gamePanel.gameWon()) victoire();
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        //droite();
        gamePanel.movePlayer1("Droite");
        gamePanel.movePlayer2(); 
        gamePanel.movePlayer3();
        contentPane.repaint();
        if(gamePanel.gameLost()) defaite();
        else if(gamePanel.gameWon()) victoire();
    }//GEN-LAST:event_jButton5ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    // End of variables declaration//GEN-END:variables


    /**
     * Permet d'ajouter un menu &agrave; la JFrame pass&eacute;e en param&egrave;tre
     * @param f la JFrame recevant le menu
     */

    public void genererMenu(JFrame f){
        barre=new JMenuBar();
        fichier=new JMenu("Fichier");
        quitter=new JMenuItem("Quitter");
        stop=new JMenuItem("Stop");
        pause=new JMenuItem("Pause");
        play=new JMenuItem("Play");



        stop.addActionListener(new java.awt.event.ActionListener(){;
            public void actionPerformed(java.awt.event.ActionEvent e){
                stopGame();
            }
        });

        quitter.addActionListener(new java.awt.event.ActionListener(){;
            public void actionPerformed(java.awt.event.ActionEvent e){
                System.exit(0);
            }
        });

        pause.addActionListener(new java.awt.event.ActionListener(){;
            public void actionPerformed(java.awt.event.ActionEvent e){
                pauseGame();
            }
        });

        play.addActionListener(new java.awt.event.ActionListener(){;
            public void actionPerformed(java.awt.event.ActionEvent e){
                startGame();
            }
        });

        fichier.add(pause);
        fichier.add(play);

        fichier.add(stop);
        fichier.add(quitter);
        barre.add(fichier);
        f.setJMenuBar(barre);
    }



   

    /**
     * Permet de mettre en pause le jeu
     */
    
    @Override
    public void pauseGame(){
        jButton1.setEnabled(false);
        jButton2.setEnabled(false);
        jButton4.setEnabled(false);
        jButton5.setEnabled(false);
        gamePaused=true;

    }

    /**
     * Permet de d&eacute;marrer une partie
     */

    private void play(){
        
        add(gamePanel);
        initComponents();
        contentPane.repaint();
        contentPane.revalidate();
        gamePaused=false;

    }
    
    /**
     * Permet de stopper le jeu (perte des donn&eacute;es si non sauvegard&eacute;es)
     */
    @Override
    public void stopGame(){
        manager.reset(gamePanel);
        gamePaused=false;
        contentPane.removeAll();
        contentPane.repaint();
        contentPane.revalidate();
    }

    /**
     * Affiche la victoire du joueur
     */

    private void victoire(){
        contentPane.removeAll();
        try{
            BufferedImage i = ImageIO.read(new File("src\\thebimbo\\images\\fondVictoire.png"));
            ImageIcon ii = new ImageIcon(i);
            contentPane.setLayout(new BorderLayout());
            contentPane.add(new JLabel(ii));
        }catch(IOException e){
            System.out.println("L'image n'a pas pu être chargée");
            contentPane.setLayout(new FlowLayout());
            contentPane.add(new JLabel("Vous avez gagné la partie !"));
        }
        contentPane.repaint();
        contentPane.revalidate();

    }

    /**
     * Affiche la d&eacute;faite du joueur
     */

    private void defaite(){
        contentPane.removeAll();
        try{
            BufferedImage i = ImageIO.read(new File("src\\thebimbo\\images\\fondDefaite.png"));
            ImageIcon ii = new ImageIcon(i);
            contentPane.setLayout(new BorderLayout());
            contentPane.add(new ImagePanel(ii));
        }catch(IOException e){
            System.out.println("L'image n'a pas pu être chargée");
            contentPane.setLayout(new FlowLayout());
            contentPane.add(new JLabel("Vous avez perdu la partie !"));
        }
        contentPane.repaint();
        contentPane.revalidate();

    }

    /**
     * Permet de d&eacute;marrer une partie (perte des donn&eacute;es si non sauvegard&eacute;es et que le jeu n'est pas en pause)
     */
    @Override
    public void startGame(){
        contentPane.removeAll();
        
        if(!gamePaused){
            
            manager.reset(gamePanel);
        }
        contentPane.repaint();
        play();
    

    }
    
    /**
     * Permet de charger une nouvelle partie depuis un fichier
     * @param file le fichier &agrave; charger
     */
    @Override
    public void loadGame(File file){
        manager.load(file);
        contentPane.repaint();
        gamePaused=false;
        
    }
    
    /**
     * Permet de sauvegarder l'&eacute;tat actuel du Manager
     * @param file le fichier recevant la sauvegarde
     */
    @Override
    public void saveGame(File file){
        manager.save(file);
    }


    private void newBouton(){
        jPanel2.removeAll();

        jPanel2.setLayout(new java.awt.GridLayout(2, 3));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 438, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 112, Short.MAX_VALUE)
        );
        jPanel2.add(jPanel4);

        jPanel2.add(jButton4);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 438, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 112, Short.MAX_VALUE)
        );

        jPanel2.add(jPanel5);

        jPanel2.add(jButton1);

        jPanel2.add(jButton2);

        jPanel2.add(jButton5);

        contentPane.repaint();
        contentPane.revalidate();

    }

   

    
    private void add(JPanel jPanel2) {
        contentPane.add(jPanel2);
    }
    
    private void setLayout(GridLayout gridLayout) {
        contentPane.setLayout(gridLayout);
    }
    
    /**
     * Permet de r&eacute;cup&eacute;rer le JPanel contenant tous les &eacute;l&eacute;ments graphiques du jeu
     * @return le content pane
     */
    public JPanel getContentPane(){
        return contentPane;
    }
    


    /*##########################################################################
    #                             END METHODE                                  #
    ##########################################################################*/

}
